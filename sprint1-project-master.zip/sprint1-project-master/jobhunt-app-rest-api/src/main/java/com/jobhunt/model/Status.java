package com.jobhunt.model;

public enum Status {
	Available,
	NotAvailable;
}
