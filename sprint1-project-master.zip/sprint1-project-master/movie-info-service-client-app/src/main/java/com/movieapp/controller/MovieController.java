package com.movieapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.movieapp.model.Movie;
import com.movieapp.service.MovieService;

@Controller
public class MovieController {

	@Autowired
	private MovieService service;
	
	@PostMapping("/add-movie")
	public String addMovie(@ModelAttribute("movie") Movie movie) {
		service.saveMovie(movie);
		return "showMovie.jsp";
	}
	
	@GetMapping("/search-movie")
	public String getMovie(@RequestParam("id") long id,Model m) {
		Movie movie = service.getMovieById(id);
		if(movie == null) {
			m.addAttribute("errorMsg", "Id not found!!!");
			return "index.jsp";
		}
		m.addAttribute("movie", movie);
		return "showMovie.jsp";
	}
	
	@GetMapping("/delete")
	public String deleteMovie(@RequestParam("id") long id,Model m) {
		service.deleteMovie(id);
		List<Movie> movieList = service.getAllMovies();
		m.addAttribute("movies", movieList);
		return "show-all.jsp";
	}
	
	@GetMapping("/show-all")
	public String showAllMovies(Model m) {
		List<Movie> movieList = service.getAllMovies();
		m.addAttribute("movies", movieList);
		return "show-all.jsp";
	}
}
