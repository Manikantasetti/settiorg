package com.movieapp.model;

public class Movie {

	private long movieId;
	private String movieName;
	private String director;
	private String date;
	
	public Movie() {
		
	}

	public Movie(long movieId, String movieName, String director, String date) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.director = director;
		this.date = date;
	}

	public long getMovieId() {
		return movieId;
	}

	public void setMovieId(long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", director=" + director + ", date=" + date
				+ "]";
	}
}
