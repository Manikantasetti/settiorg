package com.movieapp.service;

import java.util.List;

import com.movieapp.model.Movie;

public interface MovieService {

	public Movie saveMovie(Movie movie);
	
	public Movie getMovieById(long id);
	
	public void deleteMovie(long id);
	
	public List<Movie> getAllMovies();
}
