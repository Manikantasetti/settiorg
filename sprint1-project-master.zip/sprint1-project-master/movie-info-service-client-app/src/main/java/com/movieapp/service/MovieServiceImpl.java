package com.movieapp.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.movieapp.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private RestTemplate movieRestClient;
	
	@Value("${MOVIE_REST_API_URL}")
	private String movieRestApiUrl;
	
	@Override
	public Movie saveMovie(Movie movie) {
		Movie savedEmployee = movieRestClient.postForObject(movieRestApiUrl, movie, Movie.class);
		return savedEmployee;
	}

	@Override
	public Movie getMovieById(long id) {
		Movie movie=null;
		try {
			movie = movieRestClient.getForObject(movieRestApiUrl+id, Movie.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return movie;
	}

	@Override
	public void deleteMovie(long id) {
		movieRestClient.delete(movieRestApiUrl+id);
	}

	@Override
	public List<Movie> getAllMovies() {
		Movie[] movies = movieRestClient.getForObject(movieRestApiUrl, Movie[].class);
		List<Movie> movieList = Arrays.asList(movies);
		return movieList;
	}

}
